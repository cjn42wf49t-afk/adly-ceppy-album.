# Album Foto Adly & Ceppy

Website album foto responsif untuk HP, dengan desain minimalis hitam-putih.

## 1. Cara menambahkan foto

1. Buka folder `images` dan salin foto kalian ke sana.
2. Sebaiknya gunakan nama file sederhana, misalnya `foto-1.jpg` atau `jalan-sore.webp`.
3. Buka `index.html` dengan editor teks.
4. Cari bagian `const photos = [` di dekat bagian bawah file.
5. Hapus komentar contoh lalu tulis daftar foto seperti ini:

```js
const photos = [
  { src: "images/foto-1.jpg", caption: "Jalan sore", date: "01" },
  { src: "images/foto-2.jpg", caption: "Momen favorit", date: "02" },
];
```

Nama file harus sama persis dengan file di folder `images`. Simpan `index.html`, lalu buka lagi untuk memeriksa tampilannya.

## 2. Cara mencoba di HP atau komputer

- Di komputer, buka `index.html` dengan browser untuk melihat hasilnya.
- Untuk menguji di HP, cara termudah adalah mempublikasikan website mengikuti langkah berikut. Jangan kirim foto pribadi ke layanan publik jika kalian tidak ingin orang lain melihatnya.

## 3. Cara mempublikasikan gratis dengan GitHub Pages

1. Masuk atau buat akun di GitHub.
2. Buat repository baru, misalnya `adly-ceppy-album`. Jika ingin publik, pilih **Public**.
3. Unggah `index.html` dan folder `images` beserta foto yang ingin ditampilkan.
4. Di repository, buka **Settings → Pages**.
5. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/ (root)`, lalu tekan **Save**.
7. Tunggu proses publikasi selesai. GitHub akan menampilkan alamat website pada halaman Pages.

Alamat website biasanya berbentuk `https://NAMA-AKUN.github.io/adly-ceppy-album/`.

## Penting tentang privasi

Repository dan website publik bisa dilihat orang lain. Siapa pun yang memiliki alamat website dapat melihat foto yang diunggah; foto juga dapat disalin atau dibagikan. Unggah hanya foto yang kalian berdua setujui untuk dibagikan. Jangan sertakan alamat rumah, nomor telepon, sekolah, atau informasi pribadi lain.

Website ini belum memiliki login, penyimpanan unggahan, atau fitur mengunggah foto langsung dari halaman. Untuk menambah atau mengganti foto, edit daftar `photos` di `index.html` dan unggah perubahan ke hosting.
